import json,urllib.request,urllib.parse,concurrent.futures,datetime,hashlib,base64
from pathlib import Path
r=Path('/tmp/safe155.BGpHjMge/evidence'); packages=json.loads((r/'new-packages.json').read_text());now=datetime.datetime.now(datetime.timezone.utc);cutoff=now-datetime.timedelta(days=14)
def check(item):
 key,integrity=item;name,ver=key.rsplit('@',1);url='https://registry.npmjs.org/'+urllib.parse.quote(name,safe='')
 with urllib.request.urlopen(url) as f: raw=f.read();headers=dict(f.headers)
 doc=json.loads(raw);(r/('registry-'+name.replace('/','_')+'.json')).write_bytes(raw)
 version=doc['versions'][ver];published=doc['time'][ver];dist=version['dist'];matching=dist.get('integrity')==integrity
 with urllib.request.urlopen(dist['tarball']) as f: tar=f.read()
 algorithm,digest=integrity.split('-',1);actual=base64.b64encode(hashlib.new(algorithm,tar).digest()).decode()
 return dict(package=name,version=ver,published=published,eligible=datetime.datetime.fromisoformat(published.replace('Z','+00:00'))<=cutoff,integrityMatchesRegistry=matching,tarballIntegrityVerified=actual==digest,registry=url,tarball=dist['tarball'],registryDate=headers.get('Date'))
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: results=list(pool.map(check,packages.items()))
report=dict(checkedAt=now.isoformat(),cutoff=cutoff.isoformat(),packages=results);(r/'quarantine-integrity.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
