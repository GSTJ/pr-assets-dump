const assert=require('node:assert/strict');
const {Linter}=require('/tmp/safe155.BGpHjMge/source/node_modules/eslint');
const plugin=require('/tmp/safe155.BGpHjMge/packed/package');
const linter=new Linter();
const config={...plugin.configs['flat/recommended'], files:['**/*.jsx']};
for(const [code,count] of [['const count=0; const x=<div>{count && <span/>}</div>;',1],['const count=0; const x=<div>{!!count && <span/>}</div>;',0],['let ready=true; ready=0; const x=<div>{ready && <span/>}</div>;',1]]) {
 const messages=linter.verify(code,[config],{filename:'smoke.jsx'});assert.equal(messages.length,count,JSON.stringify(messages));assert.ok(messages.every(m=>m.ruleId==='safe-jsx/jsx-explicit-boolean'));console.log('PASS',code,'diagnostics:',messages.length);
}
const code='const count=0; const x=<div>{count && <span/>}</div>';const fixed=linter.verifyAndFix(code,[config],{filename:'smoke.jsx'});assert.equal(fixed.messages.length,0);assert.equal(fixed.fixed,true);console.log('PASS autofix:',fixed.output);assert.equal(plugin.meta.version,'1.3.9');console.log('Packed plugin exports, metadata, unsafe/explicit/mutable cases and autofix pass.');
