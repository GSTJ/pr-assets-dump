import json,urllib.request,subprocess
from pathlib import Path
r=Path('/tmp/safe155.BGpHjMge/evidence');report=[]
for name,version,advisory in [('minimatch','11.0.1','GHSA-g3hv-75wg-m249'),('glob','14.0.2','GHSA-3g3m-2fjr-6pw4'),('deepmerge',None,'GHSA-gcqx-w48m-w2h4')]:
 with urllib.request.urlopen('https://registry.npmjs.org/'+name) as f:doc=json.load(f)
 (r/('audit-registry-'+name+'.json')).write_text(json.dumps(doc))
 adv=json.loads(subprocess.check_output(['gh','api','/advisories/'+advisory]));(r/(advisory+'.json')).write_text(json.dumps(adv,indent=2));print(name, json.dumps(adv.get('vulnerabilities')),doc.get('dist-tags'))
 report.append(dict(package=name,firstPatched=version,published=doc['time'].get(version) if version else None,advisory=advisory,description=adv['description']))
(r/'audit-triage.json').write_text(json.dumps(report,indent=2));print(json.dumps([{k:v for k,v in a.items() if k!='description'} for a in report],indent=2))
