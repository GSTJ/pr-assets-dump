import json,subprocess,urllib.request
from pathlib import Path
r=Path('/tmp/safe155.BGpHjMge/evidence');tag=json.loads((r/'release-tag.json').read_text());rel=json.loads((r/'latest-release.json').read_text());sha=tag['object']['sha'];
def api(path): return json.loads(subprocess.check_output(['gh','api','repos/GSTJ/safe-jsx/'+path]))
import base64
changelog=base64.b64decode(api('contents/CHANGELOG.md?ref='+sha)['content']).decode();start=changelog.index('## [');end=changelog.find('\n## [',start+1);notes=changelog[start:end if end!=-1 else None].strip();assert notes==tag['message'].strip()==rel['body'].strip();assert tag['tag']=='v1.3.9'
comparison=api('compare/'+sha+'...ba6dc623672a003b270cadecdb37b8b522f59024');(r/'since-release.json').write_text(json.dumps(comparison,indent=2))
with urllib.request.urlopen('https://registry.npmjs.org/eslint-plugin-safe-jsx/1.3.9') as f: npm=json.load(f)
(r/'published-package.json').write_text(json.dumps(npm,indent=2));assert npm['version']=='1.3.9';assert comparison['status'] in ['ahead','identical'];print('v1.3.9 annotated tag',tag['sha'],'target',sha,'matches release body and tagged changelog; reachable from tested head. npm 1.3.9 exists.');print('Since release:',[(x['filename'],x['status']) for x in comparison['files']]);print('Commits:',[(x['sha'],x['commit']['message'].splitlines()[0]) for x in comparison['commits']])
