import subprocess,json,hashlib
from pathlib import Path
root=Path('/tmp/safe155.BGpHjMge'); source=root/'source';e=root/'evidence';results=[]
print('GSTJ/safe-jsx PR155 | head ba6dc623672a003b270cadecdb37b8b522f59024',flush=True)
for label,args in [('frozen-install',['pnpm','install','--frozen-lockfile']),('plugin-tests',['pnpm','run','test']),('release-controls',['pnpm','run','release:check']),('lint',['pnpm','run','lint']),('format',['pnpm','run','format']),('typecheck',['pnpm','run','typecheck']),('build',['pnpm','run','build']),('changelog',['pnpm','run','changelog:check']),('greetings',['node','tools/greetings-workflow-check.mjs']),('pack',['npm','pack','--ignore-scripts','--json','--pack-destination',str(e)]),('audit',['pnpm','audit','--json'])]:
 print('\n$ '+' '.join(args),flush=True)
 p=subprocess.run(args,cwd=source,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(e/(label+'.log')).write_text(p.stdout);print(p.stdout,flush=True);print('EXIT',p.returncode,flush=True);results.append(dict(check=label,exit=p.returncode))
(e/'results.json').write_text(json.dumps(results,indent=2))
print('\nRESULTS '+json.dumps(results),flush=True)
